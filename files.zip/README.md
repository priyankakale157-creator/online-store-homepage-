# ShopVibe Backend — Setup Guide

## Folder Structure
```
shopvibe-backend/
├── server.js              ← Main entry point
├── package.json           ← Dependencies
├── .env.example           ← Copy this to .env and fill values
├── .env                   ← Your secret config (DON'T commit to Git!)
│
├── middleware/
│   └── auth.js            ← JWT token verification
│
├── models/
│   ├── User.js            ← User schema (name, email, password)
│   ├── Product.js         ← Product schema
│   ├── Cart.js            ← Cart schema
│   └── Order.js           ← Order schema
│
├── routes/
│   ├── auth.js            ← POST /register, POST /login
│   ├── products.js        ← GET/POST /products
│   ├── cart.js            ← GET/POST/PUT/DELETE /cart
│   └── orders.js          ← GET/POST /orders
│
└── api.js                 ← Add to your FRONTEND project
```

---

## Step 1: Set up MongoDB Atlas (Free)

1. Go to https://www.mongodb.com/atlas
2. Click "Try Free" → create an account
3. Create a **free cluster** (M0 tier)
4. Click "Connect" → "Connect your application"
5. Copy the connection string (looks like `mongodb+srv://...`)

---

## Step 2: Install and configure

```bash
# Navigate to backend folder
cd shopvibe-backend

# Install all packages
npm install

# Create your .env file
cp .env.example .env
```

Open `.env` and fill in:
```
PORT=5000
MONGODB_URI=mongodb+srv://YOUR_USER:YOUR_PASS@cluster0.xxxxx.mongodb.net/shopvibe
JWT_SECRET=any_long_random_string_here
```

---

## Step 3: Run the server

```bash
# Development (auto-restarts on file changes)
npm run dev

# Production
npm start
```

You should see:
```
🚀 Server running on http://localhost:5000
✅ MongoDB connected successfully
```

---

## Step 4: Seed sample products

Open your browser or Postman and hit:
```
POST http://localhost:5000/api/products/seed/demo
```

This adds 6 sample products to your database.

---

## Step 5: Test the API

### Register a user
```
POST http://localhost:5000/api/auth/register
Body: { "name": "Test User", "email": "test@test.com", "password": "123456" }
```

### Login
```
POST http://localhost:5000/api/auth/login
Body: { "email": "test@test.com", "password": "123456" }
```
→ Copy the `token` from the response

### Get products
```
GET http://localhost:5000/api/products
```

### Add to cart (use token from login)
```
POST http://localhost:5000/api/cart
Header: Authorization: Bearer YOUR_TOKEN
Body: { "productId": "PRODUCT_ID_FROM_ABOVE", "quantity": 1 }
```

---

## Step 6: Connect frontend

Copy `api.js` to your ShopVibe frontend folder.  
Add this line to the bottom of your HTML (before `</body>`):

```html
<script src="api.js"></script>
```

---

## Step 7: Deploy to Render (Free)

1. Push your backend to GitHub (make sure .env is in .gitignore!)
2. Go to https://render.com → New → Web Service
3. Connect your GitHub repo
4. Set environment variables in Render dashboard (same as .env)
5. Build command: `npm install`
6. Start command: `node server.js`

After deploy, update `API_BASE` in `api.js`:
```js
const API_BASE = 'https://your-app-name.onrender.com/api';
```

---

## API Reference

| Method | Route | Auth Required | Description |
|--------|-------|---------------|-------------|
| POST | /api/auth/register | No | Create account |
| POST | /api/auth/login | No | Login |
| GET | /api/auth/profile | Yes | Get user profile |
| GET | /api/products | No | List all products |
| GET | /api/products?category=Men | No | Filter by category |
| GET | /api/products/:id | No | Single product |
| POST | /api/cart | Yes | Add to cart |
| GET | /api/cart | Yes | View cart |
| PUT | /api/cart/:productId | Yes | Update quantity |
| DELETE | /api/cart/:productId | Yes | Remove item |
| POST | /api/orders | Yes | Place order |
| GET | /api/orders | Yes | Order history |
| PUT | /api/orders/:id/cancel | Yes | Cancel order |
