// ============================================
// models/Cart.js - Shopping Cart Schema
// ============================================

const mongoose = require('mongoose');

const cartItemSchema = new mongoose.Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,  // Links to Product model
    ref: 'Product',
    required: true
  },
  quantity: {
    type: Number,
    required: true,
    min: [1, 'Quantity must be at least 1'],
    default: 1
  }
});

const cartSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,  // Links to User model
    ref: 'User',
    required: true,
    unique: true  // One cart per user
  },
  items: [cartItemSchema]  // Array of cart items
}, {
  timestamps: true
});

// ── Virtual: calculate total price ──────────
cartSchema.virtual('totalPrice').get(function() {
  return this.items.reduce((total, item) => {
    return total + (item.product.price * item.quantity);
  }, 0);
});

module.exports = mongoose.model('Cart', cartSchema);
