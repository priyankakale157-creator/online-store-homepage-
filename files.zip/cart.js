// ============================================
// routes/cart.js - Cart Management Routes
// All routes require login (verifyToken)
// ============================================

const express = require('express');
const router = express.Router();
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const verifyToken = require('../middleware/auth');

// Apply verifyToken to ALL cart routes
// Users must be logged in to use the cart
router.use(verifyToken);

// ── GET /api/cart ────────────────────────────
// Get the logged-in user's cart
router.get('/', async (req, res) => {
  try {
    // populate('items.product') replaces product IDs with full product objects
    const cart = await Cart.findOne({ user: req.user.id })
                           .populate('items.product');

    if (!cart) {
      return res.json({ items: [], totalAmount: 0 });
    }

    // Calculate total amount
    const totalAmount = cart.items.reduce((total, item) => {
      return total + (item.product.price * item.quantity);
    }, 0);

    res.json({ items: cart.items, totalAmount });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── POST /api/cart ───────────────────────────
// Add a product to cart (or increase quantity if already there)
// Body: { productId: "...", quantity: 1 }
router.post('/', async (req, res) => {
  try {
    const { productId, quantity = 1 } = req.body;

    // Check product exists
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    // Find user's cart or create a new one
    let cart = await Cart.findOne({ user: req.user.id });

    if (!cart) {
      // Create new cart for this user
      cart = new Cart({ user: req.user.id, items: [] });
    }

    // Check if product is already in cart
    const existingItem = cart.items.find(
      item => item.product.toString() === productId
    );

    if (existingItem) {
      // Product already in cart – increase quantity
      existingItem.quantity += quantity;
    } else {
      // Add new item to cart
      cart.items.push({ product: productId, quantity });
    }

    await cart.save();
    await cart.populate('items.product');

    const totalAmount = cart.items.reduce((total, item) => {
      return total + (item.product.price * item.quantity);
    }, 0);

    res.json({
      message: 'Added to cart!',
      items: cart.items,
      totalAmount,
      itemCount: cart.items.length
    });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── PUT /api/cart/:productId ─────────────────
// Update quantity of a product in cart
// Body: { quantity: 3 }
router.put('/:productId', async (req, res) => {
  try {
    const { quantity } = req.body;
    const { productId } = req.params;

    const cart = await Cart.findOne({ user: req.user.id });
    if (!cart) {
      return res.status(404).json({ message: 'Cart not found' });
    }

    const item = cart.items.find(
      item => item.product.toString() === productId
    );

    if (!item) {
      return res.status(404).json({ message: 'Item not found in cart' });
    }

    if (quantity <= 0) {
      // Remove item if quantity is 0 or less
      cart.items = cart.items.filter(
        item => item.product.toString() !== productId
      );
    } else {
      item.quantity = quantity;
    }

    await cart.save();
    await cart.populate('items.product');

    const totalAmount = cart.items.reduce((total, item) => {
      return total + (item.product.price * item.quantity);
    }, 0);

    res.json({ message: 'Cart updated!', items: cart.items, totalAmount });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── DELETE /api/cart/:productId ──────────────
// Remove a product from cart
router.delete('/:productId', async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id });
    if (!cart) {
      return res.status(404).json({ message: 'Cart not found' });
    }

    cart.items = cart.items.filter(
      item => item.product.toString() !== req.params.productId
    );

    await cart.save();
    res.json({ message: 'Item removed from cart!', itemCount: cart.items.length });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── DELETE /api/cart ─────────────────────────
// Clear entire cart (called after order is placed)
router.delete('/', async (req, res) => {
  try {
    await Cart.findOneAndDelete({ user: req.user.id });
    res.json({ message: 'Cart cleared!' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
