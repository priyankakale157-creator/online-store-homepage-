// ============================================
// middleware/auth.js - JWT Token Verification
// ============================================
// This middleware protects routes that require login.
// Add it to any route: router.get('/profile', verifyToken, handler)

const jwt = require('jsonwebtoken');

const verifyToken = (req, res, next) => {
  // Token comes in the header like: Authorization: Bearer eyJhbGci...
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Get part after "Bearer "

  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    // Verify and decode the token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach user info to request object
    next(); // Move to the next middleware/route handler
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or expired token.' });
  }
};

module.exports = verifyToken;
