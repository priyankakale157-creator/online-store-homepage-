// ============================================
// routes/orders.js - Order Management Routes
// All routes require login (verifyToken)
// ============================================

const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const verifyToken = require('../middleware/auth');

router.use(verifyToken);

// ── POST /api/orders ─────────────────────────
// Place a new order (converts cart to order)
// Body: { shippingAddress: {...}, paymentMethod: "COD" }
router.post('/', async (req, res) => {
  try {
    const { shippingAddress, paymentMethod } = req.body;

    // Get user's cart
    const cart = await Cart.findOne({ user: req.user.id })
                           .populate('items.product');

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Your cart is empty!' });
    }

    // Calculate total
    const totalAmount = cart.items.reduce((total, item) => {
      return total + (item.product.price * item.quantity);
    }, 0);

    // Build order items (save product details at time of order)
    const orderItems = cart.items.map(item => ({
      product: item.product._id,
      name: item.product.name,
      image: item.product.image,
      price: item.product.price,
      quantity: item.quantity
    }));

    // Create the order
    const order = await Order.create({
      user: req.user.id,
      items: orderItems,
      totalAmount,
      shippingAddress,
      paymentMethod: paymentMethod || 'COD',
      status: 'Pending'
    });

    // Clear the cart after order is placed
    await Cart.findOneAndDelete({ user: req.user.id });

    res.status(201).json({
      message: '🎉 Order placed successfully!',
      order
    });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── GET /api/orders ──────────────────────────
// Get all orders for the logged-in user
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user.id })
                              .sort({ createdAt: -1 }); // Newest first

    res.json({ count: orders.length, orders });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── GET /api/orders/:id ──────────────────────
// Get a specific order by ID
router.get('/:id', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    // Make sure user can only see their own orders
    if (order.user.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Access denied' });
    }

    res.json(order);

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── PUT /api/orders/:id/cancel ───────────────
// Cancel an order (only if still Pending)
router.put('/:id/cancel', async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.user.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Access denied' });
    }

    if (order.status !== 'Pending') {
      return res.status(400).json({
        message: `Cannot cancel order with status: ${order.status}`
      });
    }

    order.status = 'Cancelled';
    await order.save();

    res.json({ message: 'Order cancelled successfully', order });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
