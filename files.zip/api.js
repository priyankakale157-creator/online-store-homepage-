// ============================================
// api.js - Frontend API Integration for ShopVibe
// Add this file to your frontend project.
// Include in HTML: <script src="api.js"></script>
// ============================================

// 🔧 CHANGE THIS to your deployed backend URL
// For local development: 'http://localhost:5000'
// After deployment (e.g. Render): 'https://your-app.onrender.com'
const API_BASE = 'http://localhost:5000/api';

// ── Helper: get token from localStorage ─────
const getToken = () => localStorage.getItem('shopvibe_token');

// ── Helper: make authenticated API calls ────
const authFetch = (url, options = {}) => {
  const token = getToken();
  return fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,   // Send JWT token
      ...options.headers
    }
  });
};

// ============================================
// AUTH FUNCTIONS
// ============================================

// Register a new user
async function registerUser(name, email, password) {
  try {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.message);

    // Save token and user info to localStorage
    localStorage.setItem('shopvibe_token', data.token);
    localStorage.setItem('shopvibe_user', JSON.stringify(data.user));

    alert(`Welcome, ${data.user.name}! 🎉`);
    updateUIAfterLogin(data.user);
    return data;

  } catch (error) {
    alert('Registration failed: ' + error.message);
  }
}

// Login existing user
async function loginUser(email, password) {
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.message);

    localStorage.setItem('shopvibe_token', data.token);
    localStorage.setItem('shopvibe_user', JSON.stringify(data.user));

    alert(`Welcome back, ${data.user.name}!`);
    updateUIAfterLogin(data.user);
    return data;

  } catch (error) {
    alert('Login failed: ' + error.message);
  }
}

// Logout user
function logoutUser() {
  localStorage.removeItem('shopvibe_token');
  localStorage.removeItem('shopvibe_user');
  location.reload();
}

// Check if user is logged in
function isLoggedIn() {
  return !!getToken();
}

// ============================================
// PRODUCT FUNCTIONS
// ============================================

// Load all products (with optional filters)
async function loadProducts(options = {}) {
  try {
    const params = new URLSearchParams(options).toString();
    const res = await fetch(`${API_BASE}/products?${params}`);
    const data = await res.json();

    if (!res.ok) throw new Error(data.message);

    displayProducts(data.products);
    return data.products;

  } catch (error) {
    console.error('Failed to load products:', error.message);
  }
}

// Display products in the UI
function displayProducts(products) {
  const container = document.querySelector('.products-grid') ||
                    document.querySelector('[data-products]');
  if (!container) return;

  if (products.length === 0) {
    container.innerHTML = '<p>No products found.</p>';
    return;
  }

  container.innerHTML = products.map(product => `
    <div class="product-card" data-id="${product._id}">
      <img src="${product.image}" alt="${product.name}" loading="lazy">
      <div class="product-info">
        <h3>${product.name}</h3>
        <div class="price">
          <span class="current-price">₹${product.price.toLocaleString()}</span>
          ${product.originalPrice
            ? `<span class="original-price">₹${product.originalPrice.toLocaleString()}</span>
               <span class="discount">${Math.round((1 - product.price/product.originalPrice) * 100)}% OFF</span>`
            : ''}
        </div>
        <div class="rating">⭐ ${product.rating} (${product.reviewCount})</div>
        <button onclick="addToCart('${product._id}')" class="btn-add-cart">
          Add to Cart
        </button>
      </div>
    </div>
  `).join('');
}

// ============================================
// CART FUNCTIONS
// ============================================

// Add item to cart
async function addToCart(productId, quantity = 1) {
  if (!isLoggedIn()) {
    alert('Please login to add items to cart');
    // Open your login modal here:
    document.querySelector('#login-modal')?.classList.add('active');
    return;
  }

  try {
    const res = await authFetch(`${API_BASE}/cart`, {
      method: 'POST',
      body: JSON.stringify({ productId, quantity })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message);

    // Update cart count badge in navbar
    updateCartCount(data.itemCount);

    // Show success notification
    showNotification(`Added to cart! 🛒`);
    return data;

  } catch (error) {
    alert('Failed to add to cart: ' + error.message);
  }
}

// Get and display cart
async function loadCart() {
  if (!isLoggedIn()) {
    document.querySelector('.cart-items').innerHTML =
      '<p>Please login to view your cart</p>';
    return;
  }

  try {
    const res = await authFetch(`${API_BASE}/cart`);
    const data = await res.json();

    if (!res.ok) throw new Error(data.message);

    displayCart(data.items, data.totalAmount);
    return data;

  } catch (error) {
    console.error('Failed to load cart:', error.message);
  }
}

// Display cart items
function displayCart(items, totalAmount) {
  const cartContainer = document.querySelector('.cart-items');
  const totalEl = document.querySelector('.cart-total');

  if (!cartContainer) return;

  if (items.length === 0) {
    cartContainer.innerHTML = '<p>Your cart is empty 🛒</p>';
    if (totalEl) totalEl.textContent = '₹0';
    return;
  }

  cartContainer.innerHTML = items.map(item => `
    <div class="cart-item" data-id="${item.product._id}">
      <img src="${item.product.image}" alt="${item.product.name}" width="60">
      <div>
        <p>${item.product.name}</p>
        <p>₹${item.product.price} × ${item.quantity}</p>
      </div>
      <div class="quantity-controls">
        <button onclick="updateCartItem('${item.product._id}', ${item.quantity - 1})">-</button>
        <span>${item.quantity}</span>
        <button onclick="updateCartItem('${item.product._id}', ${item.quantity + 1})">+</button>
      </div>
      <button onclick="removeFromCart('${item.product._id}')">Remove</button>
    </div>
  `).join('');

  if (totalEl) totalEl.textContent = `₹${totalAmount.toLocaleString()}`;
}

// Update cart item quantity
async function updateCartItem(productId, quantity) {
  try {
    const res = await authFetch(`${API_BASE}/cart/${productId}`, {
      method: 'PUT',
      body: JSON.stringify({ quantity })
    });
    const data = await res.json();
    displayCart(data.items, data.totalAmount);
    updateCartCount(data.items.length);
  } catch (error) {
    console.error('Update failed:', error.message);
  }
}

// Remove item from cart
async function removeFromCart(productId) {
  try {
    const res = await authFetch(`${API_BASE}/cart/${productId}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    loadCart(); // Refresh cart display
    updateCartCount(data.itemCount);
  } catch (error) {
    console.error('Remove failed:', error.message);
  }
}

// ============================================
// ORDER FUNCTIONS
// ============================================

// Place an order from cart
async function placeOrder(shippingAddress, paymentMethod = 'COD') {
  if (!isLoggedIn()) {
    alert('Please login to place an order');
    return;
  }

  try {
    const res = await authFetch(`${API_BASE}/orders`, {
      method: 'POST',
      body: JSON.stringify({ shippingAddress, paymentMethod })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message);

    alert(`🎉 Order placed! Order ID: ${data.order._id}`);
    loadCart(); // Cart is now empty
    updateCartCount(0);
    return data.order;

  } catch (error) {
    alert('Order failed: ' + error.message);
  }
}

// Get user's order history
async function loadOrders() {
  try {
    const res = await authFetch(`${API_BASE}/orders`);
    const data = await res.json();

    if (!res.ok) throw new Error(data.message);

    displayOrders(data.orders);
    return data.orders;

  } catch (error) {
    console.error('Failed to load orders:', error.message);
  }
}

// Display orders in UI
function displayOrders(orders) {
  const container = document.querySelector('.orders-list');
  if (!container) return;

  if (orders.length === 0) {
    container.innerHTML = '<p>No orders yet. Start shopping! 🛍️</p>';
    return;
  }

  container.innerHTML = orders.map(order => `
    <div class="order-card">
      <h4>Order #${order._id.slice(-8).toUpperCase()}</h4>
      <p>Status: <span class="status-badge ${order.status.toLowerCase()}">${order.status}</span></p>
      <p>Total: ₹${order.totalAmount.toLocaleString()}</p>
      <p>Date: ${new Date(order.createdAt).toLocaleDateString('en-IN')}</p>
      <p>${order.items.length} item(s)</p>
      ${order.status === 'Pending'
        ? `<button onclick="cancelOrder('${order._id}')">Cancel Order</button>`
        : ''}
    </div>
  `).join('');
}

// Cancel an order
async function cancelOrder(orderId) {
  if (!confirm('Are you sure you want to cancel this order?')) return;

  try {
    const res = await authFetch(`${API_BASE}/orders/${orderId}/cancel`, {
      method: 'PUT'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);

    alert('Order cancelled successfully');
    loadOrders();

  } catch (error) {
    alert('Cancellation failed: ' + error.message);
  }
}

// ============================================
// UI HELPER FUNCTIONS
// ============================================

// Update cart count badge in navbar
function updateCartCount(count) {
  const badge = document.querySelector('.cart-count') ||
                document.querySelector('[data-cart-count]');
  if (badge) badge.textContent = count;
}

// Show a brief notification (toast)
function showNotification(message) {
  const toast = document.createElement('div');
  toast.className = 'toast-notification';
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 20px; right: 20px;
    background: #2e7d32; color: white; padding: 12px 20px;
    border-radius: 8px; z-index: 9999; font-size: 14px;
    animation: slideIn 0.3s ease;
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// Update the login button in navbar after login
function updateUIAfterLogin(user) {
  const loginBtn = document.querySelector('[data-login-btn]') ||
                   document.querySelector('.login-btn');
  if (loginBtn) loginBtn.textContent = user.name;

  // Close login modal if open
  document.querySelector('#login-modal')?.classList.remove('active');
}

// ============================================
// CONNECT EXISTING SHOPVIBE FORMS
// ============================================

// Connect your existing login/register forms to the API
document.addEventListener('DOMContentLoaded', () => {
  // Auto-restore login state
  const savedUser = localStorage.getItem('shopvibe_user');
  if (savedUser) {
    updateUIAfterLogin(JSON.parse(savedUser));
  }

  // Connect Sign In form
  const signInBtn = document.querySelector('button[type="submit"]');
  if (signInBtn) {
    signInBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      const emailInput = document.querySelector('input[type="email"]');
      const passwordInput = document.querySelector('input[type="password"]');
      if (emailInput && passwordInput) {
        await loginUser(emailInput.value, passwordInput.value);
      }
    });
  }

  // Load products on page load
  loadProducts();

  // Load cart count
  if (isLoggedIn()) {
    loadCart();
  }
});
