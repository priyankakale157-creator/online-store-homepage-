// ============================================
// routes/products.js - Product Listing Routes
// ============================================

const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const verifyToken = require('../middleware/auth');

// ── GET /api/products ────────────────────────
// Get all products (with optional filters)
// Examples:
//   /api/products
//   /api/products?category=Electronics
//   /api/products?category=Men&sort=price_low
//   /api/products?search=shoes
router.get('/', async (req, res) => {
  try {
    const { category, sort, search, featured } = req.query;

    // Build filter object
    let filter = {};
    if (category) filter.category = category;
    if (featured) filter.isFeatured = true;
    if (search) {
      filter.name = { $regex: search, $options: 'i' }; // Case-insensitive search
    }

    // Build sort object
    let sortBy = {};
    if (sort === 'price_low')  sortBy = { price: 1 };   // Ascending
    if (sort === 'price_high') sortBy = { price: -1 };  // Descending
    if (sort === 'rating')     sortBy = { rating: -1 };
    if (sort === 'newest')     sortBy = { createdAt: -1 };

    const products = await Product.find(filter).sort(sortBy);

    res.json({
      count: products.length,
      products
    });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── GET /api/products/:id ────────────────────
// Get a single product by ID
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── POST /api/products ───────────────────────
// Add a new product (admin only in production, open here for demo)
router.post('/', verifyToken, async (req, res) => {
  try {
    const product = await Product.create(req.body);
    res.status(201).json({ message: 'Product added!', product });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(e => e.message);
      return res.status(400).json({ message: messages.join(', ') });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ── POST /api/products/seed ──────────────────
// Seed the database with sample products (for testing)
router.post('/seed/demo', async (req, res) => {
  try {
    await Product.deleteMany({}); // Clear existing products

    const sampleProducts = [
      {
        name: "Men's Casual Shirt",
        description: "Comfortable cotton casual shirt for everyday wear",
        price: 799,
        originalPrice: 1499,
        category: "Men",
        image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
        rating: 4.2,
        reviewCount: 128,
        isFeatured: true
      },
      {
        name: "Women's Floral Dress",
        description: "Beautiful floral print summer dress",
        price: 1299,
        originalPrice: 2499,
        category: "Women",
        image: "https://images.unsplash.com/photo-1572804013427-4d7ca7268217?w=400",
        rating: 4.5,
        reviewCount: 89
      },
      {
        name: "Wireless Earbuds",
        description: "True wireless earbuds with 24hr battery life",
        price: 1999,
        originalPrice: 3999,
        category: "Electronics",
        image: "https://images.unsplash.com/photo-1605464315542-bda3e2f4e605?w=400",
        rating: 4.3,
        reviewCount: 256,
        isFeatured: true
      },
      {
        name: "Running Sneakers",
        description: "Lightweight running shoes with cushioned sole",
        price: 2499,
        originalPrice: 4999,
        category: "Shoes",
        image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400",
        rating: 4.6,
        reviewCount: 312,
        isFeatured: true
      },
      {
        name: "Smartwatch",
        description: "Feature-rich smartwatch with health tracking",
        price: 3999,
        originalPrice: 7999,
        category: "Electronics",
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400",
        rating: 4.4,
        reviewCount: 178
      },
      {
        name: "Women's Handbag",
        description: "Elegant leather handbag for all occasions",
        price: 1799,
        originalPrice: 3499,
        category: "Women",
        image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400",
        rating: 4.1,
        reviewCount: 94
      }
    ];

    const products = await Product.insertMany(sampleProducts);
    res.json({ message: `✅ ${products.length} sample products added!`, products });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
