// ============================================
// models/Product.js - Product Schema
// ============================================

const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Description is required']
  },
  price: {
    type: Number,
    required: [true, 'Price is required'],
    min: [0, 'Price cannot be negative']
  },
  originalPrice: {
    type: Number,  // For showing "was ₹1999, now ₹999"
    default: null
  },
  category: {
    type: String,
    required: true,
    enum: ['Men', 'Women', 'Electronics', 'Shoes', 'Home', 'Beauty']
  },
  image: {
    type: String,  // URL to the product image
    default: 'https://via.placeholder.com/300x300'
  },
  rating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  reviewCount: {
    type: Number,
    default: 0
  },
  stock: {
    type: Number,
    default: 100,
    min: 0
  },
  isFeatured: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
